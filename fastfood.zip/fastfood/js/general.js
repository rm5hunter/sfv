jQuery(document).ready(function() {
	jQuery('#slider-home').carousel({
	  interval: 6000,
	  pause: "hover"
	})
});